﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace transformations_géométriques
{
    public partial class MainWindow : Window
    {
        private double _translateX;
        private double _translateY;
        private double _rotateAngle;
        private double _scaleFactor;

        // Variables pour garder trace des états précédents du rectangle
        private double _initialX = 100;
        private double _initialY = 100;
        private double _initialAngle = 0;
        private double _initialScale = 1;

        // Variables pour garder trace des états précédents
        private double _previousX;
        private double _previousY;
        private double _previousAngle;
        private double _previousScale;

        public MainWindow()
        {
            InitializeComponent();

            // Initialiser les états précédents
            _previousX = _initialX;
            _previousY = _initialY;
            _previousAngle = _initialAngle;
            _previousScale = _initialScale;
        }

        private void TranslateButton_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(TranslateX.Text, out _translateX) && double.TryParse(TranslateY.Text, out _translateY))
            {
                CapturePreviousState();
                ShowTransformationState("Translation");
                TranslateRectangle();
            }
            else
            {
                MessageBox.Show("Veuillez entrer des valeurs numériques valides pour la translation.");
            }
        }

        private void RotateButton_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(RotateAngle.Text, out _rotateAngle))
            {
                CapturePreviousState();
                ShowTransformationState("Rotation");
                RotateRectangle();
            }
            else
            {
                MessageBox.Show("Veuillez entrer une valeur numérique valide pour la rotation.");
            }
        }

        private void ScaleButton_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(ScaleFactor.Text, out _scaleFactor))
            {
                CapturePreviousState();
                ShowTransformationState("Echelle");
                ScaleRectangle();
            }
            else
            {
                MessageBox.Show("Veuillez entrer une valeur numérique valide pour l'échelle.");
            }
        }

        private void TransformButton_Click(object sender, RoutedEventArgs e)
        {
            CapturePreviousState();
            ShowTransformationState("Transformation combinée");
            TransformRectangle();
        }

        private void CapturePreviousState()
        {
            // Capturer l'état précédent avant la transformation
            _previousX = _initialX;
            _previousY = _initialY;
            _previousAngle = _initialAngle;
            _previousScale = _initialScale;
        }

        private void UpdateTrace(string action)
        {
            // Enregistrer l'état précédent dans les traces
            string traceEntry = $"{DateTime.Now}: {action} - Ancien état: X: {_previousX}, Y: {_previousY}, Angle: {_previousAngle}, Echelle: {_previousScale}\n" +
                                $"Nouvel état: X: {_initialX}, Y: {_initialY}, Angle: {_initialAngle}, Echelle: {_initialScale}\n";
           
        }

        private void ShowTransformationState(string action)
        {
            // Affichage des anciens et nouveaux états
            string oldState = $"Ancien état : X = {_initialX}, Y = {_initialY}, Angle = {_initialAngle}, Echelle = {_initialScale}";
            string newState = $"Nouvel état après {action}: X = {MyRectangle.RenderTransform.Value.OffsetX}, Y = {MyRectangle.RenderTransform.Value.OffsetY}, Angle = {_rotateAngle}, Echelle = {_scaleFactor}";

            // Mettre à jour le TextBox pour afficher l'ancien et le nouvel état
            MatrixTextBox.Text = $"Transformation : {action}\n" +
                                 $"{oldState}\n" +
                                 $"{newState}\n";
        }

        private void TranslateRectangle()
        {
            var transform = new TranslateTransform(_translateX, _translateY);
            MyRectangle.RenderTransform = transform;
            _initialX += _translateX; // Mettre à jour la position initiale après translation
            _initialY += _translateY;

            // Mettre à jour la trace
            UpdateTrace($"Translation: X = {_translateX}, Y = {_translateY}");
        }

        private void RotateRectangle()
        {
            var transform = new RotateTransform(_rotateAngle);
            MyRectangle.RenderTransform = transform;
            _initialAngle = _rotateAngle; // Mettre à jour l'angle initial après rotation

            // Mettre à jour la trace
            UpdateTrace($"Rotation: Angle = {_rotateAngle}");
        }

        private void ScaleRectangle()
        {
            var transform = new ScaleTransform(_scaleFactor, _scaleFactor);
            MyRectangle.RenderTransform = transform;
            _initialScale = _scaleFactor; // Mettre à jour l'échelle initiale après mise à l'échelle

            // Mettre à jour la trace
            UpdateTrace($"Scale: Factor = {_scaleFactor}");
        }

        private void TransformRectangle()
        {
            var transformGroup = new TransformGroup();

            // Appliquer la translation
            var translate = new TranslateTransform(_translateX, _translateY);
            transformGroup.Children.Add(translate);

            // Appliquer la rotation
            var rotate = new RotateTransform(_rotateAngle);
            transformGroup.Children.Add(rotate);

            // Appliquer l'échelle
            var scale = new ScaleTransform(_scaleFactor, _scaleFactor);
            transformGroup.Children.Add(scale);

            // Appliquer toutes les transformations à la forme
            MyRectangle.RenderTransform = transformGroup;

            // Mettre à jour la trace
            UpdateTrace("Transformation combinée");
        }

        private void ShowMatrixButton_Click(object sender, RoutedEventArgs e)
        {
            // Créer une transformation combinée
            var transformGroup = new TransformGroup();

            // Appliquer la translation
            var translate = new TranslateTransform(_translateX, _translateY);
            transformGroup.Children.Add(translate);

            // Appliquer la rotation
            var rotate = new RotateTransform(_rotateAngle);
            transformGroup.Children.Add(rotate);

            // Appliquer l'échelle
            var scale = new ScaleTransform(_scaleFactor, _scaleFactor);
            transformGroup.Children.Add(scale);

            // Récupérer la matrice combinée
            Matrix matrix = transformGroup.Value;

            // Afficher la matrice de transformation
            string matrixText = $"Matrice de transformation:\n" +
                                $"M11: {matrix.M11}\n" +
                                $"M12: {matrix.M12}\n" +
                                $"M21: {matrix.M21}\n" +
                                $"M22: {matrix.M22}\n" +
                                $"offsetX: {matrix.OffsetX}\n" +
                                $"offsetY: {matrix.OffsetY}";

            MatrixTextBox.Text = matrixText;
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            // Réinitialiser les transformations
            MyRectangle.RenderTransform = null;
            MatrixTextBox.Clear(); // Réinitialiser la matrice
            TranslateX.Clear();
            TranslateY.Clear();
            RotateAngle.Clear();
            ScaleFactor.Clear();

            // Réinitialiser les valeurs d'état
            _initialX = 100;
            _initialY = 100;
            _initialAngle = 0;
            _initialScale = 1;

            // Réinitialiser les états précédents
            _previousX = _initialX;
            _previousY = _initialY;
            _previousAngle = _initialAngle;
            _previousScale = _initialScale;

            // Réinitialiser les traces
           
        }
    }

}