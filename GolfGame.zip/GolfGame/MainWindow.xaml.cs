﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace GolfGame
{
    public partial class MainWindow : Window
    {
        private const double GRAVITY = 9.81; // m/s²
        private const double SCALE_FACTOR = 5.0; // Pixels per meter
        private const double TIME_STEP = 0.05; // seconds

        private DispatcherTimer simulationTimer;
        private double timeElapsed;
        private double currentX, currentY;
        private double velocityX, velocityY;
        private List<Point> trajectoryPoints;

        private double mass;
        private double diameter;
        private double dragCoefficient;
        private double airDensity;
        private double crossSectionalArea;

        private double holePositionX;
        private bool isSimulating;

        public MainWindow()
        {
            InitializeComponent();

            simulationTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(TIME_STEP)
            };
            simulationTimer.Tick += SimulationTimer_Tick;

            holePositionX = 700;
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double velocity = double.Parse(tbVelocity.Text, CultureInfo.InvariantCulture);
                double angle = double.Parse(tbAngle.Text, CultureInfo.InvariantCulture);
                mass = double.Parse(tbMass.Text, CultureInfo.InvariantCulture);
                diameter = double.Parse(tbDiameter.Text, CultureInfo.InvariantCulture);
                dragCoefficient = double.Parse(tbDrag.Text, CultureInfo.InvariantCulture);
                airDensity = double.Parse(tbDensity.Text, CultureInfo.InvariantCulture);

                if (mass <= 0 || diameter <= 0 || dragCoefficient <= 0 || airDensity <= 0)
                {
                    MessageBox.Show("Les valeurs physiques doivent être positives");
                    return;
                }

                if (angle <= 0 || angle >= 90)
                {
                    MessageBox.Show("L'angle doit être compris entre 0 et 90 degrés");
                    return;
                }

                double angleRad = angle * Math.PI / 180.0;
                velocityX = velocity * Math.Cos(angleRad);
                velocityY = velocity * Math.Sin(angleRad);
                crossSectionalArea = Math.PI * Math.Pow(diameter / 2, 2);

                ResetSimulation();

                tbResult.Text = "Ball in flight...";
                isSimulating = true;
                simulationTimer.Start();
            }
            catch (FormatException)
            {
                MessageBox.Show("Format de nombre invalide. Utilisez le point décimal (ex: 0.45)");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Valeur numérique trop grande");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur inattendue: {ex.Message}");
            }
        }

        private void SimulationTimer_Tick(object sender, EventArgs e)
        {
            if (!isSimulating) return;

            timeElapsed += TIME_STEP;

            double speed = Math.Sqrt(velocityX * velocityX + velocityY * velocityY);
            if (speed == 0) return;

            double dragForce = 0.5 * airDensity * speed * speed * dragCoefficient * crossSectionalArea;

            double dragAccelX = (dragForce / mass) * (velocityX / speed);
            double dragAccelY = (dragForce / mass) * (velocityY / speed);

            velocityX -= dragAccelX * TIME_STEP;
            velocityY -= (dragAccelY + GRAVITY) * TIME_STEP;

            currentX += velocityX * TIME_STEP * SCALE_FACTOR;
            currentY -= velocityY * TIME_STEP * SCALE_FACTOR;

            if (currentY >= 255)
            {
                currentY = 255;
                velocityY = -velocityY * 0.5;
                velocityX *= 0.8;

                if (Math.Abs(velocityX) < 0.5 && Math.Abs(velocityY) < 0.5)
                {
                    EndSimulation();
                    CheckHole();
                    return;
                }
            }

            if (timeElapsed % 0.2 < TIME_STEP)
            {
                trajectoryPoints.Add(new Point(currentX, currentY));
                UpdateTrajectoryPath();
            }

            Canvas.SetLeft(golfBall, currentX);
            Canvas.SetTop(golfBall, currentY);

            double distanceMeters = (currentX - 50) / SCALE_FACTOR;
            double heightMeters = (255 - currentY) / SCALE_FACTOR;

            tbTime.Text = $"Time: {timeElapsed:F2}s";
            tbDistanceTraveled.Text = $"Distance: {distanceMeters:F1}m";
            tbHeight.Text = $"Height: {heightMeters:F1}m";

            if (currentX > canvas1.ActualWidth || currentX < 0 || currentY < 0)
            {
                EndSimulation();
                tbResult.Text = "Ball out of bounds!";
            }
        }

        private void ResetSimulation()
        {
            timeElapsed = 0;
            currentX = 50;
            currentY = 255;
            trajectoryPoints = new List<Point>();
            Canvas.SetLeft(golfBall, currentX);
            Canvas.SetTop(golfBall, currentY);
            trajectoryPath.Points = null;
        }

        private void UpdateTrajectoryPath()
        {
            trajectoryPath.Points = new PointCollection(trajectoryPoints);
        }

        private void CheckHole()
        {
            double holeCenterX = holePositionX + 10;
            double ballCenterX = currentX + 7.5;

            if (Math.Abs(ballCenterX - holeCenterX) < 15 && currentY >= 255 && currentY <= 265)
            {
                tbResult.Text = "HOLE IN ONE! AMAZING SHOT!";
            }
            else
            {
                double distanceToHole = Math.Abs(ballCenterX - holeCenterX) / SCALE_FACTOR;
                tbResult.Text = $"Ball stopped {distanceToHole:F1}m from the hole";
            }
        }

        private void EndSimulation()
        {
            isSimulating = false;
            simulationTimer.Stop();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            simulationTimer.Stop();
            isSimulating = false;

            Canvas.SetLeft(golfBall, 50);
            Canvas.SetTop(golfBall, 255);
            trajectoryPath.Points = null;

            tbVelocity.Text = "30";
            tbAngle.Text = "45";
            tbDistance.Text = "100"; // Optionnel, non utilisé
            tbMass.Text = "0.045";
            tbDiameter.Text = "0.042";
            tbDrag.Text = "0.25";
            tbDensity.Text = "1.225";

            tbTime.Text = "Time: 0s";
            tbDistanceTraveled.Text = "Distance: 0m";
            tbHeight.Text = "Height: 0m";
            tbResult.Text = "Ready to play...";
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
