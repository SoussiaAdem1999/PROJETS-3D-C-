﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace AdvancedPaintApp
{
    public partial class MainWindow : Window
    {
        private Point startPoint;
        private Point endPoint;
        private bool isDrawing;
        private string currentShape;
        private Color fillColor = Colors.Transparent;
        private Color strokeColor = Colors.Black;
        private bool selectingFillColor = true;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnRectangle_Click(object sender, RoutedEventArgs e)
        {
            currentShape = "Rectangle";
        }

        private void btnTriangle_Click(object sender, RoutedEventArgs e)
        {
            currentShape = "Triangle";
        }

        private void btnLine_Click(object sender, RoutedEventArgs e)
        {
            currentShape = "Line";
        }

        private void btnPolygon_Click(object sender, RoutedEventArgs e)
        {
            currentShape = "Polygon";
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            DrawingCanvas.Children.Clear();
        }

        private void btnFillColor_Click(object sender, RoutedEventArgs e)
        {
            selectingFillColor = true;
            ColorPalette.Visibility = Visibility.Visible;
        }

        private void btnStrokeColor_Click(object sender, RoutedEventArgs e)
        {
            selectingFillColor = false;
            ColorPalette.Visibility = Visibility.Visible;
        }

        private void ColorSelected(object sender, MouseButtonEventArgs e)
        {
            if (sender is Rectangle rect && rect.Fill is SolidColorBrush brush)
            {
                if (selectingFillColor)
                    fillColor = brush.Color;
                else
                    strokeColor = brush.Color;

                ColorPalette.Visibility = Visibility.Collapsed;
            }
        }

        private void DrawingCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                startPoint = e.GetPosition(DrawingCanvas);
                isDrawing = true;
            }
        }

        private void DrawShape()
        {
            // Supprimer l'éventuelle forme de prévisualisation
            if (previewShape != null)
            {
                DrawingCanvas.Children.Remove(previewShape);
                previewShape = null;
            }

            Shape shape = CreateShape();
            if (shape != null)
            {
                DrawingCanvas.Children.Add(shape);
            }
        }


        private void DrawingCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (isDrawing)
            {
                isDrawing = false;
                endPoint = e.GetPosition(DrawingCanvas);
                DrawShape();
            }
        }

        private void DrawShapePreview()
        {
            Shape shape = CreateShape();
            if (shape != null)
                DrawingCanvas.Children.Add(shape);
        }

        private void DrawShape()
        {
            Shape shape = CreateShape();
            if (shape != null)
                DrawingCanvas.Children.Add(shape);
        }

        private Shape CreateShape()
        {
            Shape shape = null;

            switch (currentShape)
            {
                case "Rectangle":
                    shape = new Rectangle
                    {
                        Stroke = new SolidColorBrush(strokeColor),
                        Fill = new SolidColorBrush(fillColor),
                        StrokeThickness = 2,
                        Width = Math.Abs(startPoint.X - endPoint.X),
                        Height = Math.Abs(startPoint.Y - endPoint.Y)
                    };
                    Canvas.SetLeft(shape, Math.Min(startPoint.X, endPoint.X));
                    Canvas.SetTop(shape, Math.Min(startPoint.Y, endPoint.Y));
                    break;

                case "Triangle":
                    shape = new Polygon
                    {
                        Stroke = new SolidColorBrush(strokeColor),
                        Fill = new SolidColorBrush(fillColor),
                        StrokeThickness = 2,
                        Points = new PointCollection
                        {
                            startPoint,
                            new Point(endPoint.X, startPoint.Y),
                            endPoint
                        }
                    };
                    break;

                case "Line":
                    shape = new Line
                    {
                        Stroke = new SolidColorBrush(strokeColor),
                        StrokeThickness = 2,
                        X1 = startPoint.X,
                        Y1 = startPoint.Y,
                        X2 = endPoint.X,
                        Y2 = endPoint.Y
                    };
                    break;

                case "Polygon":
                    // Placeholder: draw a simple pentagon
                    double centerX = (startPoint.X + endPoint.X) / 2;
                    double centerY = (startPoint.Y + endPoint.Y) / 2;
                    double radius = Math.Min(Math.Abs(endPoint.X - startPoint.X), Math.Abs(endPoint.Y - startPoint.Y)) / 2;

                    var points = new PointCollection();
                    for (int i = 0; i < 5; i++)
                    {
                        double angle = i * 2 * Math.PI / 5 - Math.PI / 2;
                        points.Add(new Point(
                            centerX + radius * Math.Cos(angle),
                            centerY + radius * Math.Sin(angle)));
                    }

                    shape = new Polygon
                    {
                        Stroke = new SolidColorBrush(strokeColor),
                        Fill = new SolidColorBrush(fillColor),
                        StrokeThickness = 2,
                        Points = points
                    };
                    break;
            }

            return shape;
        }
    }
}
